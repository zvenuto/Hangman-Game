import java.util.HashSet;
import java.util.Set;

public class HangmanGame {
    private String wordToGuess; // The word the player needs to guess
    private StringBuilder displayWord; // The word displayed with guessed letters and underscores
    private Set<Character> guessedLetters; // All guessed letters
    private int remainingAttempts; // Remaining number of incorrect guesses allowed

    /**
     * Constructs a new HangmanGame based on the selected difficulty level.
     * 
     * @param difficulty The difficulty level ("easy", "medium", "hard").
     */
    public HangmanGame(String difficulty) {
        wordToGuess = getRandomWord(difficulty).toUpperCase();
        displayWord = new StringBuilder("_".repeat(wordToGuess.length()));
        guessedLetters = new HashSet<>();

        // Set remaining attempts based on difficulty
        switch (difficulty.toLowerCase()) {
            case "easy":
                remainingAttempts = 10;
                break;
            case "medium":
                remainingAttempts = 7;
                break;
            case "hard":
                remainingAttempts = 5;
                break;
            default:
                remainingAttempts = 7; // Default to medium
        }
    }

    /**
     * Gets a random word based on the difficulty level using WordBank.
     * 
     * @param difficulty The difficulty level.
     * @return A random word from the WordBank.
     */
    private String getRandomWord(String difficulty) {
        return WordBank.getRandomWord(difficulty);
    }

    /**
     * Processes a guessed letter.
     * 
     * @param letter The letter guessed by the player.
     * @return True if the letter is in the word, false otherwise.
     */
    public boolean guessLetter(char letter) {
        letter = Character.toUpperCase(letter);

        // Check if the letter has already been guessed
        if (guessedLetters.contains(letter)) {
            return false;
        }

        guessedLetters.add(letter);

        // Check if the letter is in the word
        if (wordToGuess.indexOf(letter) >= 0) {
            // Reveal all occurrences of the letter in the display word
            for (int i = 0; i < wordToGuess.length(); i++) {
                if (wordToGuess.charAt(i) == letter) {
                    displayWord.setCharAt(i, letter);
                }
            }
            return true;
        } else {
            // Decrease remaining attempts for incorrect guesses
            remainingAttempts--;
            return false;
        }
    }

    /**
     * Returns the word to guess.
     * 
     * @return The word to guess.
     */
    public String getWordToGuess() {
        return wordToGuess;
    }

    /**
     * Returns the display word with guessed letters and underscores.
     * 
     * @return The display word.
     */
    public String getDisplayWord() {
        return displayWord.toString();
    }

    /**
     * Returns the remaining attempts.
     * 
     * @return The remaining attempts.
     */
    public int getRemainingAttempts() {
        return remainingAttempts;
    }

    /**
     * Checks if the game is won.
     * 
     * @return True if the player has guessed all the letters, false otherwise.
     */
    public boolean isGameWon() {
        return displayWord.indexOf("_") == -1;
    }

    /**
     * Checks if the game is lost.
     * 
     * @return True if the player has run out of attempts, false otherwise.
     */
    public boolean isGameLost() {
        return remainingAttempts <= 0;
    }

    /**
     * Returns a string of all incorrect guesses made so far.
     * 
     * @return A string of incorrect guesses separated by spaces.
     */
    public String getIncorrectGuesses() {
        StringBuilder incorrectGuesses = new StringBuilder();
        for (char letter : guessedLetters) {
            if (wordToGuess.indexOf(letter) == -1) { // Letter not in the word
                incorrectGuesses.append(letter).append(" ");
            }
        }
        return incorrectGuesses.toString().trim();
    }
}

    


