import java.util.List;
import java.util.Random;

public class WordBank {
    // Word lists for each difficulty level
    private static final List<String> EASY_WORDS = List.of("cat", "dog", "sun", "fish", "tree", "love", "sing", "bird", "bear", "dark", "moon", "game", "rose", "star", "evil", "city");
    private static final List<String> MEDIUM_WORDS = List.of("apple", "river", "cloud", "house", "forest", "circle", "turtle", "cactus", "island", "carrot", "flower", "animal", "parrot", "spring", "guitar");
    private static final List<String> HARD_WORDS = List.of("elephant", "mountain", "astronomy", "developer", "hangman", "champion", "daylight", "favorite", "clinical", "package", "qualify", "activity", "cinderella", "basketball", "logical", "business");

    /**
     * Returns a random word based on the difficulty level.
     * 
     * @param difficulty The difficulty level ("easy", "medium", "hard").
     * @return A random word from the appropriate word list.
     * @throws IllegalArgumentException If the difficulty level is invalid.
     */
    public static String getRandomWord(String difficulty) {
        Random random = new Random();
        switch (difficulty.toLowerCase()) {
            case "easy":
                return EASY_WORDS.get(random.nextInt(EASY_WORDS.size()));
            case "medium":
                return MEDIUM_WORDS.get(random.nextInt(MEDIUM_WORDS.size()));
            case "hard":
                return HARD_WORDS.get(random.nextInt(HARD_WORDS.size()));
            default:
                throw new IllegalArgumentException("Invalid difficulty level: " + difficulty);
        }
    }
}
