import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class HangmanApp extends Application {
    private HangmanGame game;
    private Label displayWordLabel;
    private Label remainingAttemptsLabel;
    private Label incorrectGuessesLabel;
    private TextField inputField;
    private Button guessButton;
    private Label gameOverLabel;  // Label for Game Over message

    @Override
    public void start(Stage primaryStage) {
        // Initial GUI setup
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        // Title
        Label title = new Label("Welcome to Hangman!");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Difficulty Info
        Label difficultyInfoLabel = new Label("Select difficulty below:\n- Easy: 10 guesses\n- Medium: 7 guesses\n- Hard: 5 guesses");
        difficultyInfoLabel.setStyle("-fx-font-size: 14px; -fx-font-style: italic;");

        // Difficulty Selection
        Label difficultyLabel = new Label("Select Difficulty:");
        ComboBox<String> difficultyComboBox = new ComboBox<>();
        difficultyComboBox.getItems().addAll("Easy", "Medium", "Hard");
        difficultyComboBox.setValue("Medium");

        // Start Button
        Button startButton = new Button("Start Game");
        startButton.setOnAction(e -> {
            String difficulty = difficultyComboBox.getValue();
            startNewGame(difficulty);
        });

        // Display Word (always visible)
        displayWordLabel = new Label("");
        displayWordLabel.setStyle("-fx-font-size: 18px;");

        // Remaining Attempts (always visible)
        remainingAttemptsLabel = new Label("");

        // Incorrect Guesses (always visible)
        incorrectGuessesLabel = new Label("");

        // Game Over Label (always visible)
        gameOverLabel = new Label("");
        gameOverLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: red;");

        // Input Field (always visible)
        Label inputLabel = new Label("Enter a letter:");
        inputField = new TextField();
        inputField.setMaxWidth(50);
        
        // Guess Button (always visible)
        guessButton = new Button("Guess");
        guessButton.setOnAction(e -> processGuess());

        // HBox for input field and guess button
        HBox inputBox = new HBox(10, inputLabel, inputField, guessButton);
        inputBox.setPadding(new Insets(5, 0, 0, 0));

        // Layout
        root.getChildren().addAll(title, difficultyInfoLabel, difficultyLabel, difficultyComboBox, startButton, 
                                  displayWordLabel, remainingAttemptsLabel, incorrectGuessesLabel, 
                                  inputBox, gameOverLabel);

        Scene scene = new Scene(root, 400, 350);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Hangman Game");
        primaryStage.show();
    }

    /**
     * Starts a new game with the selected difficulty.
     *
     * @param difficulty The difficulty level.
     */
    private void startNewGame(String difficulty) {
        // Create a new game based on the difficulty level
        game = new HangmanGame(difficulty);

        // Hide the game over message
        gameOverLabel.setVisible(false);

        // Update game UI
        displayWordLabel.setText(game.getDisplayWord());
        remainingAttemptsLabel.setText("Remaining Attempts: " + game.getRemainingAttempts());
        incorrectGuessesLabel.setText("Incorrect Guesses: ");
    }

    /**
     * Processes the player's guess.
     */
    private void processGuess() {
        if (game == null || inputField.getText().isEmpty()) {
            return;
        }
        char guess = inputField.getText().toUpperCase().charAt(0);
        inputField.clear();

        // Handle correct and incorrect guesses
        if (game.guessLetter(guess)) {
            displayWordLabel.setText(game.getDisplayWord());
        } else {
            remainingAttemptsLabel.setText("Remaining Attempts: " + game.getRemainingAttempts());
            incorrectGuessesLabel.setText("Incorrect Guesses: " + game.getIncorrectGuesses());
        }

        // Check if the game is won or lost
        if (game.isGameWon()) {
            gameOverLabel.setText("Congratulations! You guessed the word: " + game.getWordToGuess());
            gameOverLabel.setVisible(true);
        } else if (game.isGameLost()) {
            gameOverLabel.setText("Game Over. The word was: " + game.getWordToGuess());
            gameOverLabel.setVisible(true);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
